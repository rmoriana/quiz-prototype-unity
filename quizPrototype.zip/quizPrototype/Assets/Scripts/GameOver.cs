﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOver : MonoBehaviour {

    public Text rondasSuperadas, dineroGanado;
	
    //Muestra las rondas superadas y el dinero ganado al terminar el juego.
	void Start () {
        rondasSuperadas.GetComponent<Text>().text = "Rondas superadas: " + Singleton.numRondaActual.ToString();
        dineroGanado.GetComponent<Text>().text = "Dinero conseguido: " + Singleton.backMoney().ToString();
	}

}
