﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Clase que establece las carácteristicas y atributos de una pregunta.
public class Preguntas  {

	public string pregunta;
	public string []respuestas = new string[4];
	public int respuestaCorrecta; 

	public void addPregunta(string _pregunta, string respuesta_1,string respuesta_2,string respuesta_3,string respuesta_4, int _respuestaCorrecta){
		pregunta = _pregunta;
		respuestas [0] = respuesta_1;
		respuestas [1] = respuesta_2;
		respuestas [2] = respuesta_3;
		respuestas [3] = respuesta_4;

		respuestaCorrecta = _respuestaCorrecta;
	}
}
