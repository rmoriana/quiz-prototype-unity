﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Singleton : MonoBehaviour {

	public static List<Preguntas> listPreguntas = new List<Preguntas>();

	public static int numRondaActual = 0;

	public static int numPeguntaActual;

	public static Preguntas preguntaActual;


	//Generador de preguntas
	public static void initGame(){
		Preguntas pregunta1 = new Preguntas ();
		pregunta1.addPregunta ("De que color es el caballo blanco de santiago", "MARRÓN", "NEGRO", "OCRE", "BLANCO", 3);
		listPreguntas.Add (pregunta1);

		Preguntas pregunta2 = new Preguntas ();
		pregunta2.addPregunta ("Cual es la profesión del personaje de nintendo Super Mario", "POLICIA", "ARTISTA", "FONTANERO", "POLITICO", 2);
		listPreguntas.Add (pregunta2);

		Preguntas pregunta3 = new Preguntas ();
		pregunta3.addPregunta ("Nombre del actor que encarnó a Clyde en la famosa película", "DUNAWAY", "ANTONIO", "MARROWOW", "WARHOL", 0);
		listPreguntas.Add (pregunta3);

		Preguntas pregunta4 = new Preguntas ();
		pregunta4.addPregunta ("Arma utilizada para acabar con la vida de Bonnie y Clyde", "HACHA", "CUCHILLO", "LASER", "METRALLETA", 3);
		listPreguntas.Add (pregunta4);

		Preguntas pregunta5 = new Preguntas ();
		pregunta5.addPregunta ("Apellido real de Clyde",  "EMINEM", "FRANCO", "NAVARRO", "WARREN", 3);
		listPreguntas.Add (pregunta5);

		Preguntas pregunta6 = new Preguntas ();
		pregunta6.addPregunta ("Estado del sur de EE.UU del que era originaria Bonnie", "TEXAS", "EMINEM", "FLORIDA", "DUNAWAY", 0);
		listPreguntas.Add (pregunta6);

		Preguntas pregunta7 = new Preguntas ();
		pregunta7.addPregunta ("Tipo de delincuentes que eran Bonnie y Clyde", "GÁNGSTERS", "ASESINOS", "FRANCOTIRADORES", "SEXIS", 0);
		listPreguntas.Add (pregunta7);

		Preguntas pregunta8 = new Preguntas ();
		pregunta8.addPregunta ("Apellido real de Bonnie", "CLAINE", "DUNAWAY", "PARKER", "EMINEM", 2);
		listPreguntas.Add (pregunta8);

		Preguntas pregunta9 = new Preguntas ();
		pregunta9.addPregunta ("Película en la que Banderas retomó el personaje de El mariachi", "EL MARIACHI", "DESPERADO", "COCO", "EL ZORRO", 1);
		listPreguntas.Add (pregunta9);

	}

	//Establece cual es la siguiente pregunta al azar.
	public static void searchNextPregunta(){
        int numPregunta = Random.Range(0, 9);
        preguntaActual = listPreguntas[numPregunta];
	}

	//Suma el dinero total tras acertar una pregunta. El dinero es 500 * el número de ronda.
	public static int backMoney(){
		return numRondaActual*500;
	}
}
