﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour {

    private AudioClip[] listaCanciones = new AudioClip[3];
    private AudioClip sonidoAcierto,sonidoError,aplausosAcierto;
    public Button r1, r2, r3, r4;
    public Text pregunta;
    private bool respuestaHabilitada;
    	
	void Start () {
        //Cargamos la lista de preguntas en Singleton
        Singleton.initGame();

        //Cargamos la musica y los efectos de sonido
        listaCanciones[0] = Resources.Load("Music/M_07") as AudioClip;
        listaCanciones[1] = Resources.Load("Music/M_10") as AudioClip;
        listaCanciones[2] = Resources.Load("Music/M_12") as AudioClip;  
        sonidoAcierto = Resources.Load("FX/aciertoFuerte") as AudioClip;
        sonidoError = Resources.Load("FX/malFuerte") as AudioClip;
        aplausosAcierto = Resources.Load("FX/aplausos_02") as AudioClip;

        //Musica
        GetComponent<AudioSource>().clip = listaCanciones[Random.Range(0, 3)];
        GetComponent<AudioSource>().Play();
        GetComponent<AudioSource>().loop = true;

        NuevaPregunta();
	}	

    private void NuevaPregunta()
    {
        respuestaHabilitada = true;

        r1.GetComponent<Image>().sprite = Resources.Load<Sprite>("cajapregunta");
        r2.GetComponent<Image>().sprite = Resources.Load<Sprite>("cajapregunta");
        r3.GetComponent<Image>().sprite = Resources.Load<Sprite>("cajapregunta");
        r4.GetComponent<Image>().sprite = Resources.Load<Sprite>("cajapregunta");
        
        //Cogemos una pregunta al azar
        Singleton.searchNextPregunta();

        //Rellenamos los botones de pregunta y las respuestas
        pregunta.GetComponent<Text>().text = Singleton.preguntaActual.pregunta;
        r1.GetComponentInChildren<Text>().text = Singleton.preguntaActual.respuestas[0];
        r2.GetComponentInChildren<Text>().text = Singleton.preguntaActual.respuestas[1];
        r3.GetComponentInChildren<Text>().text = Singleton.preguntaActual.respuestas[2];
        r4.GetComponentInChildren<Text>().text = Singleton.preguntaActual.respuestas[3];        
    }

    //Recibe el número de la respuesta que ha marcado el jugador y la gestiona.
    public void GestionRespuesta(int numRespuesta)
    {
        if (respuestaHabilitada)
        {
            respuestaHabilitada = false;
            //Si la respuesta es correcta
            if (numRespuesta == Singleton.preguntaActual.respuestaCorrecta)
            {
                AudioSource.PlayClipAtPoint(sonidoAcierto, transform.position);

                //El publico solo aplaude a veces
                int posiblesAplausos = Random.Range(0, 3);
                if (posiblesAplausos == 0)
                {
                    AudioSource.PlayClipAtPoint(aplausosAcierto, transform.position);
                }

                switch (numRespuesta)
                {
                    case 0: r1.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba4_respGreen"); break;
                    case 1: r2.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba4_respGreen"); break;
                    case 2: r3.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba4_respGreen"); break;
                    case 3: r4.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba4_respGreen"); break;
                }

                Singleton.numRondaActual++;
                Invoke("NuevaPregunta", 3);
            }
            else
            {
                AudioSource.PlayClipAtPoint(sonidoError, transform.position);
                switch (numRespuesta)
                {
                    case 0: r1.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba1_caja_Orange"); break;
                    case 1: r2.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba1_caja_Orange"); break;
                    case 2: r3.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba1_caja_Orange"); break;
                    case 3: r4.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba1_caja_Orange"); break;
                }
                switch (Singleton.preguntaActual.respuestaCorrecta)
                {
                    case 0: r1.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba4_respGreen"); break;
                    case 1: r2.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba4_respGreen"); break;
                    case 2: r3.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba4_respGreen"); break;
                    case 3: r4.GetComponent<Image>().sprite = Resources.Load<Sprite>("prueba4_respGreen"); break;
                }

                //Escena de Game Over
                Invoke("cambioEscena", 3);
            }
        }        
    }

    void cambioEscena()
    {
        SceneManager.LoadScene("GameOver");
    }
}
